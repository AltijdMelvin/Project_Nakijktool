# wpf-propertygrid
Repackaging of Workflow Foundation's property grid for general use in WPF applications

Read the article at [CodeProject](http://www.codeproject.com/Articles/87715/Native-WPF-PropertyGrid)

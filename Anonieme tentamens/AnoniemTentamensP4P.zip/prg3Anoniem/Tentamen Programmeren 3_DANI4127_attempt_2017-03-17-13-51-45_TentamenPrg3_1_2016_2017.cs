using System;
using System.Collections.Generic;
using System.Linq;
using NUnit.Framework;
using System.Diagnostics;


Voornaam: RACQUEL
Achternaam: DANIEL
StudentNr: s41279
Klas: i1b

//!-----------------------!
//De TestCases staan na de vraag in de region. De region kan je uitklappen
//Let op sommige testcases hebben de code in commentaar staan, 
//uncomment dit dan alvorens de test te draaien
//!-----------------------!
namespace TentamenPrg3_1_2016_2017
{
    #region Vraag1
    //Vraag 1A
    //Om gemakkelijk bijvoorbeeld gegevens mee te geven aan een klasse.
    //Of om in de klasse bepaalde commando's uit te voeren in een klasse.

    //Vraag 1B
    //Lijn,Reistijd,Bus,Halte
    //

    //Vraag 1C
    //Een instantie variable moet(is het veiligst) om prive te hebben.
    //Met een property kan je een get/set instellen en zo een prive variable bewerken
    #endregion

    #region Vraag2
    public class Bus
    {
        private int _BusNr;
        private int _AantalPassagiers;
        private Lijn _RijdOpLijn;
        private DateTime _Vertrektijd;
        private string _BestuurderNaam;
        private string _voornaam;
        private string _achternaam;

        public int BusNr
        {
            get
            {
                return _BusNr;
            }
        }
        public int AantalPassagiers
        {
            get
            {
                return _AantalPassagiers;
            }
        }
        public Lijn RijdOpLijn
        {
            get
            {
                return _RijdOpLijn;
            }
        }
        public DateTime Vertrektijd
        {
            get
            {
                return _Vertrektijd;
            }
        }
        public string BestuurderNaam
        {
            get
            {
                return _BestuurderNaam;
            }
        }

        public Bus(int busNr, Lijn lijn, DateTime vertrektijd, string voornaam, string achternaam)
        {
            _BusNr = busNr;
            _RijdOpLijn = lijn;
            _Vertrektijd = vertrektijd;
            _voornaam = voornaam;
            _achternaam = achternaam;
            _BestuurderNaam = voornaam + " " + achternaam;
        }
        public void StapIn()
        {
            _AantalPassagiers++;
        }
        public void StapUit()
        {
            _AantalPassagiers--;
        }
    }

    public class Lijn
    {
        private int _LijnNr;
        private List<Halte> _Haltes = new List<Halte>();

        public Lijn(int lijnNr)
        {
            _LijnNr = Convert.ToInt32(lijnNr);
        }
        public void AddHalte(Halte halte)
        {
            _Haltes.Add(halte);
        }

        public int LijnNr
        {
            get
            {
                return _LijnNr;
            }
        }

        public List<Halte> Haltes
        {
            get
            {
                return _Haltes;
            }
        }


        //Vraag 3 Hier invullen!
        #region Vraag3
        public TimeSpan Reistijd()
        {
            return Halte.Reisduur;
        }
        #endregion
    }

    public class Halte
    {
        private static string _Naam;
        private static TimeSpan _Reisduur;

        public string Naam
        {
            get
            {
                return _Naam;
            }
            set
            {
                _Naam = value;
            }
        }

        public static TimeSpan Reisduur
        {
            get
            {
                return _Reisduur;
            }
            set
            {
                _Reisduur.Add(value);
            }
        }

        public Halte(string naam, TimeSpan reisduur)
        {
            Reisduur += reisduur;
            _Naam = naam;
        }
    }

    public class TestCasesVraag2
    {
        [Test]
        public void TestVraag2()
        {

            DateTime vertrek = new DateTime(2016, 09, 12, 14, 26, 0);

            Lijn lijn = new Lijn(612);
            Bus bus = new Bus(10, lijn, vertrek, "Joris", "Lops");

            lijn.AddHalte(new Halte("Bushalte NHL Hogeschool", TimeSpan.Zero));
            lijn.AddHalte(new Halte("Bushalte Stenden Hogeschool", TimeSpan.FromMinutes(1)));
            lijn.AddHalte(new Halte("Bushalte Wissesdwinger", TimeSpan.FromMinutes(2)));
            lijn.AddHalte(new Halte("Bushalte Harmonie", TimeSpan.FromMinutes(3)));
            lijn.AddHalte(new Halte("Bushalte Zaailand", TimeSpan.FromMinutes(1)));
            lijn.AddHalte(new Halte("Bushalte Busstation", TimeSpan.FromMinutes(5)));


            Assert.AreEqual("Joris Lops", bus.BestuurderNaam);
            Assert.AreEqual(612, bus.RijdOpLijn.LijnNr);
            Assert.AreEqual("Bushalte Wissesdwinger", bus.RijdOpLijn.Haltes[2].Naam);
            //Assert.AreEqual(TimeSpan.FromMinutes(2), bus.RijdOpLijn.Haltes[2].Reisduur);

            Assert.AreEqual(0, bus.AantalPassagiers);
            bus.StapIn();
            bus.StapIn();
            Assert.AreEqual(2, bus.AantalPassagiers);
            bus.StapUit();
            Assert.AreEqual(1, bus.AantalPassagiers);
            bus.StapUit();
            Assert.AreEqual(0, bus.AantalPassagiers);

            Assert.AreEqual(6, bus.RijdOpLijn.Haltes.Count);

            Assert.AreEqual(10, bus.BusNr);

            Assert.AreEqual(612, bus.RijdOpLijn.LijnNr);

            Assert.AreEqual(new DateTime(2016, 09, 12, 14, 26, 0), bus.Vertrektijd);

        }
    }
    #endregion

    #region Vraag3
    //Vraag 3, zie class Lijn in Vraag 2

    public class TestCasesVraag3
    {
        [Test]
        public void TestVraag3()
        {

            //DateTime vertrek = new DateTime(2016, 09, 12, 14, 26, 0);

            //Lijn lijn = new Lijn(612);
            //Bus bus = new Bus(10, lijn, vertrek, "Joris", "Lops");

            //lijn.AddHalte(new Halte("Bushalte NHL Hogeschool", TimeSpan.Zero));
            //lijn.AddHalte(new Halte("Bushalte Stenden Hogeschool", TimeSpan.FromMinutes(1)));
            //lijn.AddHalte(new Halte("Bushalte Wissesdwinger", TimeSpan.FromMinutes(2)));
            //lijn.AddHalte(new Halte("Bushalte Harmonie", TimeSpan.FromMinutes(3)));
            //lijn.AddHalte(new Halte("Bushalte Zaailand", TimeSpan.FromMinutes(1)));
            //lijn.AddHalte(new Halte("Bushalte Busstation", TimeSpan.FromMinutes(5)));

            //TimeSpan reistijd = lijn.Reistijd();
            //Assert.AreEqual(TimeSpan.FromMinutes(12), reistijd);

            //DateTime aankomst = vertrek + reistijd;
            //Assert.AreEqual(new DateTime(2016, 09, 12, 14, 38, 0), aankomst);

        }
    }
    #endregion

    #region Vraag4
    public class HalteStack
    {
        public string[] Stack = new string[20];

        public bool IsEmpty
        {
            get
            {
                bool IsIt = true;
                foreach (var x in Stack)
                {
                    if(!string.IsNullOrWhiteSpace(x))
                    {
                        IsIt = false;
                    }
                }
                return IsIt;
            }
        }

        public void Push(string halteNaam)
        {
            for (int i = 0;i < Stack.Count();i++)
            {
                if(string.IsNullOrWhiteSpace(Stack[i]))
                {
                    Stack[i] = halteNaam;
                    break;
                }
            }
        }

        public string Pop()
        {
            string Return = "";
            for (int i = Stack.Count() - 1; i > 0; i--)
            {
                if (!string.IsNullOrWhiteSpace(Stack[i]))
                {
                    Return = Stack[i];
                    Stack[i] = null;
                    break;
                }
            }
            return Return;
        }

        //Vraag 4b
        public string PrintHaltesReversed()
        {
            string ReversedAll = "";
            for (int i = 0;  i < Stack.Count(); i++)
            {
                ReversedAll += Pop() + ",";
            }
            return ReversedAll;
        }
    }

    public class TestCasesVraag4
    {
        //[Test]
        //public void Test_Vraag4A()
        //{
        //    HalteStack hs = new HalteStack();
        //    Assert.AreEqual(true, hs.IsEmpty);
        //    hs.Push("Bushalte Zaailand");
        //    Assert.AreEqual(false, hs.IsEmpty);
        //    Assert.AreEqual("Bushalte Zaailand", hs.Pop());
        //    Assert.AreEqual(true, hs.IsEmpty);

        //    hs.Push("Bushalte Zaailand");
        //    hs.Push("Bushalte Harmonie");
        //    hs.Push("Bushalte Wissesdwinger");

        //    Assert.AreEqual(false, hs.IsEmpty);
        //    Assert.AreEqual("Bushalte Wissesdwinger", hs.Pop());

        //    Assert.AreEqual(false, hs.IsEmpty);
        //    Assert.AreEqual("Bushalte Harmonie", hs.Pop());

        //    Assert.AreEqual(false, hs.IsEmpty);
        //    Assert.AreEqual("Bushalte Zaailand", hs.Pop());
        //    Assert.AreEqual(true, hs.IsEmpty);
        //}

        //[Test]
        //public void Test_Vraag4B()
        //{
        //    HalteStack hs = new HalteStack();
        //    hs.Push("Bushalte Zaailand");
        //    hs.Push("Bushalte Harmonie");
        //    hs.Push("Bushalte Wissesdwinger");
        //    hs.Push("Bushalte Stenden Hogeschool");
        //    hs.Push("Bushalte NHL Hogeschool");

        //    string reversed = hs.PrintHaltesReversed();
        //    Assert.AreEqual("Bushalte NHL Hogeschool,Bushalte Stenden Hogeschool,Bushalte Wissesdwinger,Bushalte Harmonie,Bushalte Zaailand"
        //        , reversed);
        //}
    }
    #endregion

    #region Vraag5
    public class HalteLinked
    {
        public string Naam { get; }
        public TimeSpan Reisduur { get; set; }
        public HalteLinked Volgende { get; set; }

        public HalteLinked(string naam, TimeSpan reisduur)
        {
            Naam = naam;
            Reisduur = reisduur;
        }
    }

    public class LijnLinked
    {
        private HalteLinked top = null;
        public int LijnNr { get; set; }
        LinkedList<int> lijnNrList = new LinkedList<int>();


        public LijnLinked(int lijnNr, HalteLinked halte)
        {
            LijnNr = lijnNr;
            top = halte;
            top.Volgende = top;
            top.Reisduur = Reistijd();
            lijnNrList.AddFirst(lijnNr);
        }

        //Vraag 5A
        public int Count
        {
            get
            {
                return lijnNrList.Count();
            }
        }

        //Vraag 5B
        public TimeSpan Reistijd()
        {
            TimeSpan _Reistijd = new TimeSpan(0);
            _Reistijd += Halte.Reisduur;
            return _Reistijd;
        }
    }

    public class TestCasesVraag5
    {
        [Test]
        public void Test_Vraag5A()
        {
            HalteLinked nhl = new HalteLinked("Bushalte NHL Hogeschool", TimeSpan.Zero);

            LijnLinked lijnLinked = new LijnLinked(12, nhl);
            Assert.AreEqual(1, lijnLinked.Count);

            HalteLinked stenden = new HalteLinked("Bushalte Stenden Hogeschool", TimeSpan.FromMinutes(1));
            nhl.Volgende = stenden;
            Assert.AreEqual(2, lijnLinked.Count);

            HalteLinked harmonie = new HalteLinked("Bushalte Harmonie", TimeSpan.FromMinutes(3));
            stenden.Volgende = harmonie;
            Assert.AreEqual(3, lijnLinked.Count);

            HalteLinked zaailand = new HalteLinked("Bushalte Zaailand", TimeSpan.FromMinutes(1));
            harmonie.Volgende = zaailand;
            Assert.AreEqual(4, lijnLinked.Count);

            HalteLinked busstation = new HalteLinked("Bushalte Busstation", TimeSpan.FromMinutes(5));
            zaailand.Volgende = busstation;
            Assert.AreEqual(5, lijnLinked.Count);
        }

        [Test]
        public void Test_Vraag5B()
        {
            HalteLinked nhl = new HalteLinked("Bushalte NHL Hogeschool", TimeSpan.Zero);
            HalteLinked stenden = new HalteLinked("Bushalte Stenden Hogeschool", TimeSpan.FromMinutes(1));
            HalteLinked harmonie = new HalteLinked("Bushalte Harmonie", TimeSpan.FromMinutes(3));
            HalteLinked zaailand = new HalteLinked("Bushalte Zaailand", TimeSpan.FromMinutes(1));
            HalteLinked busstation = new HalteLinked("Bushalte Busstation", TimeSpan.FromMinutes(5));

            nhl.Volgende = stenden;
            stenden.Volgende = harmonie;
            harmonie.Volgende = zaailand;
            zaailand.Volgende = busstation;

            LijnLinked lijnLinked = new LijnLinked(12, nhl);

            Assert.AreEqual(TimeSpan.FromMinutes(10), lijnLinked.Reistijd());
        }
    }
    #endregion
}
